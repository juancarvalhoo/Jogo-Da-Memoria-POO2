package jogodamemoria;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JogoDaMemoria {
    private JFrame frame;
    private JButton[] botoes;
    private String[] valores;
    private boolean[] cartasViradas;
    private int tentativas;

    private int primeiroIndice = -1;
    private int segundoIndice = -1;

    private JLabel labelTentativas;
    private JButton botaoReiniciar;
    private JButton botaoMelhores;

    private Placar placar;

    public JogoDaMemoria() {
        frame = new JFrame("Jogo da Memória com Placar");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        placar = new Placar();

        inicializarComponentes();

        frame.setSize(600, 750);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void inicializarComponentes() {
        valores = new String[] {
            "A", "A", "B", "B",
            "C", "C", "D", "D",
            "E", "E", "F", "F",
            "G", "G", "H", "H"
        };
        ArrayList<String> listaValores = new ArrayList<>();
        Collections.addAll(listaValores, valores);
        Collections.shuffle(listaValores);
        valores = listaValores.toArray(new String[0]);

        cartasViradas = new boolean[16];
        tentativas = 0;
        primeiroIndice = -1;
        segundoIndice = -1;

        JPanel painelCartas = new JPanel(new GridLayout(4, 4));
        botoes = new JButton[16];

        for (int i = 0; i < 16; i++) {
            final int idx = i;
            botoes[i] = new JButton("?");
            botoes[i].setFont(new Font("Arial", Font.BOLD, 24));
            cartasViradas[i] = false;
            botoes[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    clicarCarta(idx);
                }
            });
            painelCartas.add(botoes[i]);
        }
        frame.add(painelCartas, BorderLayout.CENTER);

        JPanel painelInferior = new JPanel(new FlowLayout());

        labelTentativas = new JLabel("Tentativas: 0");
        labelTentativas.setFont(new Font("Arial", Font.BOLD, 18));
        painelInferior.add(labelTentativas);

        botaoReiniciar = new JButton("Reiniciar");
        botaoReiniciar.setFont(new Font("Arial", Font.BOLD, 16));
        botaoReiniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                reiniciarJogo();
            }
        });
        painelInferior.add(botaoReiniciar);

        botaoMelhores = new JButton("Melhores Resultados");
        botaoMelhores.setFont(new Font("Arial", Font.BOLD, 16));
        botaoMelhores.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarMelhoresResultados();
            }
        });
        painelInferior.add(botaoMelhores);

        frame.add(painelInferior, BorderLayout.SOUTH);
    }

    private void clicarCarta(int indice) {
        if (cartasViradas[indice] || (primeiroIndice != -1 && segundoIndice != -1)) {
            return;
        }

        botoes[indice].setText(valores[indice]);
        cartasViradas[indice] = true;

        if (primeiroIndice == -1) {
            primeiroIndice = indice;
        } else {
            segundoIndice = indice;
            tentativas++;
            labelTentativas.setText("Tentativas: " + tentativas);

            if (valores[primeiroIndice].equals(valores[segundoIndice])) {
                primeiroIndice = -1;
                segundoIndice = -1;

                if (verificarFimDeJogo()) {
                    terminarJogo();
                }
            } else {
                Timer timer = new Timer(1000, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        cartasViradas[primeiroIndice] = false;
                        cartasViradas[segundoIndice] = false;
                        botoes[primeiroIndice].setText("?");
                        botoes[segundoIndice].setText("?");

                        primeiroIndice = -1;
                        segundoIndice = -1;
                    }
                });
                timer.setRepeats(false);
                timer.start();
            }
        }
    }

    private boolean verificarFimDeJogo() {
        for (boolean vira : cartasViradas) {
            if (!vira) return false;
        }
        return true;
    }

    private void reiniciarJogo() {
        ArrayList<String> listaValores = new ArrayList<>();
        Collections.addAll(listaValores, valores);
        Collections.shuffle(listaValores);
        valores = listaValores.toArray(new String[0]);

        for (int i = 0; i < 16; i++) {
            cartasViradas[i] = false;
            botoes[i].setText("?");
        }

        tentativas = 0;
        labelTentativas.setText("Tentativas: 0");
        primeiroIndice = -1;
        segundoIndice = -1;
    }

    private void terminarJogo() {
        String mensagem = "Parabéns! Você terminou o jogo em " + tentativas + " tentativas.";
        String nome = JOptionPane.showInputDialog(frame, mensagem + "\nDigite seu nome:");
        if (nome != null && !nome.trim().isEmpty()) {
            placar.adicionarEntrada(nome.trim(), tentativas);
        } else {
            nome = "Anônimo";
            placar.adicionarEntrada(nome, tentativas);
        }
        mostrarMelhoresResultados();
    }

    private void mostrarMelhoresResultados() {
        List<Placar.EntradaPlacar> melhores = placar.getMelhoresPlacares();
        StringBuilder sb = new StringBuilder();
        sb.append("Top 10 Melhores Placares:\n\n");
        int pos = 1;
        for (Placar.EntradaPlacar entrada : melhores) {
            sb.append(pos++).append(". ").append(entrada.getNome())
              .append(" - ").append(entrada.getTentativas()).append(" tentativas\n");
        }
        JOptionPane.showMessageDialog(frame, sb.toString(), "Melhores Resultados", JOptionPane.INFORMATION_MESSAGE);
    }
}
