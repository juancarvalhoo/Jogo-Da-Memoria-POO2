package jogodamemoria;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;


public class JogoDaMemoria {
    private JFrame frame;
    private JButton[] botoes;
    private String[] valores;
    private boolean[] cartasViradas;
    private int tentativas;

    public JogoDaMemoria() {
        tentativas = 0;

       
        valores = new String[] {
            "A", "A", "B", "B",
            "C", "C", "D", "D",
            "E", "E", "F", "F",
            "G", "G", "H", "H"
        };
       
        ArrayList<String> listaValores = new ArrayList<>();
        Collections.addAll(listaValores, valores);
        Collections.shuffle(listaValores);
        valores = listaValores.toArray(new String[0]);

        cartasViradas = new boolean[16];

        frame = new JFrame("Jogo da Memória v0.1");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(4, 4));
        botoes = new JButton[16];

        for (int i = 0; i < 16; i++) {
            final int indice = i;
            botoes[i] = new JButton("?");
            botoes[i].setFont(new Font("Arial", Font.BOLD, 24));
            cartasViradas[i] = false;
            botoes[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (!cartasViradas[indice]) {
                        botoes[indice].setText(valores[indice]);
                        cartasViradas[indice] = true;
                        tentativas++;
                        System.out.println("Tentativas: " + tentativas);
                    }
                }
            });
            frame.add(botoes[i]);
        }

        frame.setSize(600, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
