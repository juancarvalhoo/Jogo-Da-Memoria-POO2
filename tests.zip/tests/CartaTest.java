package jogodamemoria;


import com.jogodamemoria.Carta;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CartaTest {

    @Test
    public void testCriarCarta() {
        Carta carta = new Carta("A");
        assertEquals("A", carta.getValor());
        assertFalse(carta.isVirada());
    }

    @Test
    public void testVirarCarta() {
        Carta carta = new Carta("B");
        carta.virar();
        assertTrue(carta.isVirada());
    }
}
