package jogodamemoria;

import com.jogodamemoria.Placar;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class PlacarTest {

    @Test
    public void testAdicionarEntrada() {
        Placar placar = new Placar();
        placar.adicionarEntrada("Jogador1", 5);
        List<Placar.EntradaPlacar> melhores = placar.getMelhoresPlacares();
        assertEquals(1, melhores.size());
        assertEquals("Jogador1", melhores.get(0).getNome());
        assertEquals(5, melhores.get(0).getTentativas());
    }

    @Test
    public void testMelhoresPlacares() {
        Placar placar = new Placar();
        placar.adicionarEntrada("Jogador1", 5);
        placar.adicionarEntrada("Jogador2", 3);
        placar.adicionarEntrada("Jogador3", 7);

        List<Placar.EntradaPlacar> melhores = placar.getMelhoresPlacares();
        assertEquals(3, melhores.size());
        assertEquals("Jogador2", melhores.get(0).getNome()); 
        assertEquals(3, melhores.get(0).getTentativas());
    }
}
