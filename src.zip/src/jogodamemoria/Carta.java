package jogodamemoria;



public class Carta {
    private String valor;
    private boolean virada;

    
     
    public Carta(String valor) {
        this.valor = valor;
        this.virada = false;
    }

   
    public String getValor() {
        return valor;
    }

   
    public boolean isVirada() {
        return virada;
    }

  
    public void virar() {
        virada = !virada;
    }
}
