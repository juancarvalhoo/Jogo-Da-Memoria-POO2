package jogodamemoria;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;


public class JogoDaMemoria {
    private JFrame frame;
    private JButton[] botoes;
    private String[] valores;
    private boolean[] cartasViradas;
    private int tentativas;

    private int primeiroIndice = -1;
    private int segundoIndice = -1;

    private JLabel labelTentativas;
    private JButton botaoReiniciar;

    public JogoDaMemoria() {
        frame = new JFrame("Jogo da Memória v0.2");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        inicializarComponentes();

        frame.setSize(600, 700);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void inicializarComponentes() {
      
        valores = new String[] {
            "A", "A", "B", "B",
            "C", "C", "D", "D",
            "E", "E", "F", "F",
            "G", "G", "H", "H"
        };
     
        ArrayList<String> listaValores = new ArrayList<>();
        Collections.addAll(listaValores, valores);
        Collections.shuffle(listaValores);
        valores = listaValores.toArray(new String[0]);

        cartasViradas = new boolean[16];
        tentativas = 0;
        primeiroIndice = -1;
        segundoIndice = -1;

        JPanel painelCartas = new JPanel(new GridLayout(4, 4));
        botoes = new JButton[16];

        for (int i = 0; i < 16; i++) {
            final int idx = i;
            botoes[i] = new JButton("?");
            botoes[i].setFont(new Font("Arial", Font.BOLD, 24));
            cartasViradas[i] = false;
            botoes[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    clicarCarta(idx);
                }
            });
            painelCartas.add(botoes[i]);
        }

        frame.add(painelCartas, BorderLayout.CENTER);

        JPanel painelInferior = new JPanel(new BorderLayout());

        labelTentativas = new JLabel("Tentativas: 0");
        labelTentativas.setHorizontalAlignment(SwingConstants.CENTER);
        labelTentativas.setFont(new Font("Arial", Font.BOLD, 18));
        painelInferior.add(labelTentativas, BorderLayout.CENTER);

        botaoReiniciar = new JButton("Reiniciar");
        botaoReiniciar.setFont(new Font("Arial", Font.BOLD, 16));
        botaoReiniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                reiniciarJogo();
            }
        });
        painelInferior.add(botaoReiniciar, BorderLayout.EAST);

        frame.add(painelInferior, BorderLayout.SOUTH);
    }

    private void clicarCarta(int indice) {
        if (cartasViradas[indice] || (primeiroIndice != -1 && segundoIndice != -1)) {
            return;
        }

        botoes[indice].setText(valores[indice]);
        cartasViradas[indice] = true;

        if (primeiroIndice == -1) {
            primeiroIndice = indice;
        } else {
            segundoIndice = indice;
            tentativas++;
            labelTentativas.setText("Tentativas: " + tentativas);

            if (valores[primeiroIndice].equals(valores[segundoIndice])) {
                
                primeiroIndice = -1;
                segundoIndice = -1;

                if (verificarFimDeJogo()) {
                    JOptionPane.showMessageDialog(frame, "Parabéns! Você terminou o jogo em " + tentativas + " tentativas.");
                }
            } else {
                Timer timer = new Timer(1000, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        cartasViradas[primeiroIndice] = false;
                        cartasViradas[segundoIndice] = false;
                        botoes[primeiroIndice].setText("?");
                        botoes[segundoIndice].setText("?");

                        primeiroIndice = -1;
                        segundoIndice = -1;
                    }
                });
                timer.setRepeats(false);
                timer.start();
            }
        }
    }

    private boolean verificarFimDeJogo() {
        for (boolean vira : cartasViradas) {
            if (!vira) return false;
        }
        return true;
    }

    private void reiniciarJogo() {
       
        ArrayList<String> listaValores = new ArrayList<>();
        Collections.addAll(listaValores, valores);
        Collections.shuffle(listaValores);
        valores = listaValores.toArray(new String[0]);

        for (int i = 0; i < 16; i++) {
            cartasViradas[i] = false;
            botoes[i].setText("?");
        }

        tentativas = 0;
        labelTentativas.setText("Tentativas: 0");
        primeiroIndice = -1;
        segundoIndice = -1;
    }
}
