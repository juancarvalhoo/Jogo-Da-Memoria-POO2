package jogodamemoria;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JogoDaMemoriaLogica {
    private String[] valores;
    private boolean[] cartasViradas;
    private int tentativas;
    private int primeiroIndice = -1;
    private int segundoIndice = -1;

    public JogoDaMemoriaLogica() {
        inicializarJogo();
    }

    private void inicializarJogo() {
        valores = new String[] {
            "A", "A", "B", "B",
            "C", "C", "D", "D",
            "E", "E", "F", "F",
            "G", "G", "H", "H"
        };
        List<String> listaValores = new ArrayList<>();
        Collections.addAll(listaValores, valores);
        Collections.shuffle(listaValores);
        valores = listaValores.toArray(new String[0]);

        cartasViradas = new boolean[16];
        tentativas = 0;
    }

    public String getValor(int indice) {
        return valores[indice];
    }

    public boolean isCartaVirada(int indice) {
        return cartasViradas[indice];
    }

    public void virarCarta(int indice) {
        if (!cartasViradas[indice]) {
            cartasViradas[indice] = true;
            if (primeiroIndice == -1) {
                primeiroIndice = indice;
            } else {
                segundoIndice = indice;
                tentativas++;
            }
        }
    }

    public boolean verificarPar() {
        if (primeiroIndice != -1 && segundoIndice != -1) {
            boolean par = valores[primeiroIndice].equals(valores[segundoIndice]);
            if (!par) {
                cartasViradas[primeiroIndice] = false;
                cartasViradas[segundoIndice] = false;
            }
            primeiroIndice = -1;
            segundoIndice = -1;
            return par;
        }
        return false;
    }

    public int getTentativas() {
        return tentativas;
    }

    public boolean verificarFimDeJogo() {
        for (boolean virada : cartasViradas) {
            if (!virada) return false;
        }
        return true;
    }

    public void reiniciarJogo() {
        inicializarJogo();
    }
}
