package jogodamemoria;

import com.jogodamemoria.JogoDaMemoriaLogica;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class JogoDaMemoriaLogicaTest {

    @Test
    public void testInicializacao() {
        JogoDaMemoriaLogica jogo = new JogoDaMemoriaLogica();
        assertEquals(0, jogo.getTentativas(), "Tentativas devem iniciar em 0");
        assertFalse(jogo.verificarFimDeJogo(), "O jogo não deve estar terminado no início");
    }

    @Test
    public void testVirarCarta() {
        JogoDaMemoriaLogica jogo = new JogoDaMemoriaLogica();
        jogo.virarCarta(0);
        assertTrue(jogo.isCartaVirada(0), "A carta deve estar virada após ser clicada");
    }

    @Test
    public void testVerificarPar() {
        JogoDaMemoriaLogica jogo = new JogoDaMemoriaLogica();
        jogo.virarCarta(0);
        jogo.virarCarta(1);
        assertTrue(jogo.verificarPar(), "As cartas devem ser um par");
        assertEquals(1, jogo.getTentativas(), "Tentativas devem aumentar após verificar par");
    }

    @Test
    public void testVerificarFimDeJogo() {
        JogoDaMemoriaLogica jogo = new JogoDaMemoriaLogica();
        
        for (int i = 0; i < 16; i++) {
            jogo.virarCarta(i);
            jogo.verificarPar(); 
        }
        assertTrue(jogo.verificarFimDeJogo(), "O jogo deve estar terminado após todas as cartas serem viradas");
    }

    @Test
    public void testReiniciarJogo() {
        JogoDaMemoriaLogica jogo = new JogoDaMemoriaLogica();
        jogo.virarCarta(0);
        jogo.reiniciarJogo();
        assertEquals(0, jogo.getTentativas(), "Tentativas devem ser 0 após reiniciar");
        assertFalse(jogo.isCartaVirada(0), "A carta deve estar virada para baixo após reiniciar");
    }
}
