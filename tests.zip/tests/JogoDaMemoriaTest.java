package jogodamemoria;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JogoDaMemoria {
    private JFrame frame;
    private JButton[] botoes;
    private JogoDaMemoriaLogica logica;
    private JLabel labelTentativas;
    private JButton botaoReiniciar;
    private JButton botaoMelhores;

    public JogoDaMemoria() {
        frame = new JFrame("Jogo da Memória com Placar");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        logica = new JogoDaMemoriaLogica();
        inicializarComponentes();

        frame.setSize(600, 750);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void inicializarComponentes() {
        JPanel painelCartas = new JPanel(new GridLayout(4, 4));
        botoes = new JButton[16];

        for (int i = 0; i < 16; i++) {
            final int idx = i;
            botoes[i] = new JButton("?");
            botoes[i].setFont(new Font("Arial", Font.BOLD, 24));
            botoes[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    clicarCarta(idx);
                }
            });
            painelCartas.add(botoes[i]);
        }
        frame.add(painelCartas, BorderLayout.CENTER);

        JPanel painelInferior = new JPanel(new FlowLayout());

        labelTentativas = new JLabel("Tentativas: 0");
        labelTentativas.setFont(new Font("Arial", Font.BOLD, 18));
        painelInferior.add(labelTentativas);

        botaoReiniciar = new JButton("Reiniciar");
        botaoReiniciar.setFont(new Font("Arial", Font.BOLD, 16));
        botaoReiniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                reiniciarJogo();
            }
        });
        painelInferior.add(botaoReiniciar);

        botaoMelhores = new JButton("Melhores Resultados");
        botaoMelhores.setFont(new Font("Arial", Font.BOLD, 16));
        botaoMelhores.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarMelhoresResultados();
            }
        });
        painelInferior.add(botaoMelhores);

        frame.add(painelInferior, BorderLayout.SOUTH);
    }

    private void clicarCarta(int indice) {
        logica.virarCarta(indice);
        botoes[indice].setText(logica.getValor(indice));

        if (logica.verificarPar()) {
            if (logica.verificarFimDeJogo()) {
                terminarJogo();
            }
        } else {
            Timer timer = new Timer(1000, new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    botoes[indice].setText("?");
                    logica.virarCarta(indice); 
                }
            });
            timer.setRepeats(false);
            timer.start();
        }

        labelTentativas.setText("Tentativas: " + logica.getTentativas());
    }

    private void reiniciarJogo() {
        logica.reiniciarJogo();
        for (int i = 0; i < 16; i++) {
            botoes[i].setText("?");
        }
        labelTentativas.setText("Tentativas: 0");
    }

    private void terminarJogo() {
        String mensagem = "Parabéns! Você terminou o jogo em " + logica.getTentativas() + " tentativas.";
        String nome = JOptionPane.showInputDialog(frame, mensagem + "\nDigite seu nome:");
        if (nome != null && !nome.trim().isEmpty()) {
          
        } else {
            nome = "Anônimo";
   
        }
        mostrarMelhoresResultados();
    }

    private void mostrarMelhoresResultados() {
     
    }
}
