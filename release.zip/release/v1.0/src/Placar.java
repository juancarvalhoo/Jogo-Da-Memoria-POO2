package jogodamemoria;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;


public class Placar {

    private static final String ARQUIVO_PLACAR = "placares.csv";
    private List<EntradaPlacar> entradas;

    public Placar() {
        entradas = new ArrayList<>();
        carregarPlacares();
    }

    public void adicionarEntrada(String nome, int tentativas) {
        entradas.add(new EntradaPlacar(nome, tentativas));
        salvarPlacares();
    }

    public List<EntradaPlacar> getMelhoresPlacares() {
        return entradas.stream()
                .sorted(Comparator.comparingInt(EntradaPlacar::getTentativas))
                .limit(10)
                .collect(Collectors.toList());
    }

    private void carregarPlacares() {
        File file = new File(ARQUIVO_PLACAR);
        if (!file.exists()) {
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(",");
                if (partes.length == 2) {
                    try {
                        int tentativas = Integer.parseInt(partes[1]);
                        entradas.add(new EntradaPlacar(partes[0], tentativas));
                    } catch(NumberFormatException ignored) {}
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao carregar placares: " + e.getMessage());
        }
    }

    private void salvarPlacares() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARQUIVO_PLACAR))) {
            for (EntradaPlacar e : entradas) {
                bw.write(e.getNome() + "," + e.getTentativas());
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erro ao salvar placares: " + e.getMessage());
        }
    }

    public static class EntradaPlacar {
        private String nome;
        private int tentativas;

        public EntradaPlacar(String nome, int tentativas) {
            this.nome = nome;
            this.tentativas = tentativas;
        }

        public String getNome() {
            return nome;
        }

        public int getTentativas() {
            return tentativas;
        }
    }
}

